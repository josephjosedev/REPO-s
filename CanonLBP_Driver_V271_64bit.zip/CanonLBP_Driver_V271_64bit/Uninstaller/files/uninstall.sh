#!/bin/bash
chmod 777 "`(dirname "$0")`"/canonLBP_uninstall.sh
PASSWORD=`zenity --title='Password' --text='Please enter administrative password' --entry --hide-text`
echo $PASSWORD | sudo -S bash "`(dirname "$0")`"/canonLBP_uninstall.sh
(zenity --no-wrap --info --title "Uninstall Completed" --text="`printf "Canon LBP Printer is removed"`")


