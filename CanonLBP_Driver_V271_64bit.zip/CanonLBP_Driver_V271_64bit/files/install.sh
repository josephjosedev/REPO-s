#!/bin/bash
chmod 777 "`(dirname "$0")`"/canonLBP_install.sh
MODEL=$(zenity --title "Printer Model" --text "Type the Printer Model in the box.  Eg. LBP2900" --entry)
if [ $? = 0 ]; then
	PASSWORD=`zenity --title='Password' --text='Please enter administrative password' --entry --hide-text`
	echo $PASSWORD | sudo -S bash "`(dirname "$0")`"/canonLBP_install.sh $MODEL
	
fi
cp /usr/local/canon_lbp/canon_LBP_printer-start $HOME/Desktop/

